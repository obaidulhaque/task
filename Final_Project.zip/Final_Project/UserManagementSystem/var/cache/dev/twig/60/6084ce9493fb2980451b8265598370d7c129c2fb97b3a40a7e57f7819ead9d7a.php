<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* inc/navbar.html.twig */
class __TwigTemplate_746d1a304ba9970db1b586d1d4279941d92bf753ca9f2614895b59d939826244 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "inc/navbar.html.twig"));

        // line 1
        echo "<nav class=\"navbar navbar-expand-sm bg-primary navbar-dark\">
    <div class=\"container\">

        <a class=\"navbar-brand\" href=\"/\">User Management System</a>

       <button class=\"navbar-toggler\" type=\"button\"
               data-toggle=\"collapse\" data-target=\"#mobile-nav\">

           <span class=\"navbar-toggle-icon\"></span>
       </button>

       <div class=\"collapse navbar-collapse\" id=\"mobile-nav\">
           <ul class=\"navbar-nav ml-auto\">
               <li class=\"nav-item\">
                   <a href=\"/\" class=\"nav-link\">Home</a>
               </li>
               <li class=\"nav-item\">
                   <a href=\"/users/new\" class=\"nav-link\">Add User</a>
               </li>
               <li class=\"nav-item\">
                   <a href=\"/users/group\" class=\"nav-link\">Add Group</a>
               </li>
           </ul>
       </div>
    </div>
</nav>


";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "inc/navbar.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  40 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<nav class=\"navbar navbar-expand-sm bg-primary navbar-dark\">
    <div class=\"container\">

        <a class=\"navbar-brand\" href=\"/\">User Management System</a>

       <button class=\"navbar-toggler\" type=\"button\"
               data-toggle=\"collapse\" data-target=\"#mobile-nav\">

           <span class=\"navbar-toggle-icon\"></span>
       </button>

       <div class=\"collapse navbar-collapse\" id=\"mobile-nav\">
           <ul class=\"navbar-nav ml-auto\">
               <li class=\"nav-item\">
                   <a href=\"/\" class=\"nav-link\">Home</a>
               </li>
               <li class=\"nav-item\">
                   <a href=\"/users/new\" class=\"nav-link\">Add User</a>
               </li>
               <li class=\"nav-item\">
                   <a href=\"/users/group\" class=\"nav-link\">Add Group</a>
               </li>
           </ul>
       </div>
    </div>
</nav>


", "inc/navbar.html.twig", "E:\\xampp\\htdocs\\UserManagementSystem\\templates\\inc\\navbar.html.twig");
    }
}

<?php

namespace App\Controller;

use App\Entity\GroupTable;
use App\Entity\TNGroups;
use App\Entity\TNUserGroups;
use App\Entity\TNUsers;
use App\Entity\UserTable;

use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\IntegerType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Doctrine\ORM\EntityRepository;
use Symfony\Component\HttpFoundation\JsonResponse;

class MainController extends AbstractController
{
    /**
     * @Route(path="/", name="home")
     * @Method({"GET"})
     */
    public function index()
    {
        $repository = $this->getDoctrine()->getRepository(TNUserGroups::class);
        $users = $repository->findAll();

        return $this->render(
            'users/customerTable.html.twig',
            array('customers' => $users)
        );
    }

    /**
     * @Route("/users/new", name="new_users")
     * @Method({"GET", "POST"})
     */
    public function new()
    {
        return $this->render(
            'users/userpage.html.twig');

    }

    /**
     * @Route("/users/create", name="create_users")
     * @Method({"GET", "POST"})
     */
    public function createUser(Request $request)
    {
        $newuser = new TNUsers();

        $form = $this->createFormBuilder($newuser)
            ->add('userName', TextType::class, array('attr' =>array('class' => 'form-control')))
            ->add('emailAddress', TextType::class, array('attr' =>array('class' => 'form-control')))
            ->add('creationDate', TextType::class, array('attr' =>array('class' => 'form-control')))
            ->add('save', SubmitType::class, array(
                'label' =>'Create',
                'attr' =>array('class'=>'btn btn-primary mt-3')
            ))
            ->getForm();

        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid())
        {
            $newdata = $form->getData();

            $entityManager = $this->getDoctrine()->getManager();
            try{
                $entityManager->persist($newdata);
                $entityManager->flush();
            }catch (\Exception $e) {
                return new JsonResponse(["error" => $e->getMessage()], 500);
            }


            return $this->redirectToRoute('new_users');
        }

        return $this->render('users/new.html.twig',array(
            'form'=>$form->createView()
        ));
    }

    /**
     * @Route("/users/delete", name="delete_users")
     * @Method({"GET", "POST"})
     */
    public function deleteUser()
    {
        $repository = $this->getDoctrine()->getRepository(TNUsers::class);
        $users = $repository->findAll();

        return $this->render(
            'users/deleteuser.html.twig',
            array('customers' => $users)
        );
    }

    /**
     * @Route("/users/delete/{id}", name="delete_usersID")
     * @Method({"GET", "POST"})
     */
    public function deleteUserID($id)
    {
        $entityManager = $this->getDoctrine()->getManager();
        $userID = $entityManager->getRepository(TNUsers::class)->find($id);

        //print_r($userID);
        //exit();

        if (!$userID)
        {
            throw $this->createNotFoundException("No record for user id:".$id);
        }

        $entityManager->remove($userID);
        $entityManager->flush();

        return $this->redirectToRoute('new_users');
    }


    /**
     * @Route("/users/assigngroup", name="assign_users")
     * @Method({"GET", "POST"})
     */
    public function assignUserIntoGroup(Request $request)
    {
        $assignuser = new TNUserGroups();

        $form = $this->createFormBuilder($assignuser)
            ->add('userName', EntityType::class, [
                'class' => TNUsers::class,
                'query_builder' => function (EntityRepository $er) {
                    return $er->createQueryBuilder('u')
                        ->orderBy('u.userName', 'ASC');
                },
                'choice_label' => 'userName',
            ])
            ->add('groupName', EntityType::class, [
                'class' => TNGroups::class,
                'query_builder' => function (EntityRepository $er) {
                    return $er->createQueryBuilder('u')
                        ->orderBy('u.groupName', 'ASC');
                },
                'choice_label' => 'groupName',
            ])
            ->add('save', SubmitType::class, array(
                'label' =>'Create',
                'attr' =>array('class'=>'btn btn-primary mt-3')
            ))
            ->getForm();

        $form->handleRequest($request);


        if ($form->isSubmitted() && $form->isValid())
        {
            $newdata = $form->getData();

            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->persist($newdata);
            $entityManager->flush();

            return $this->redirectToRoute('new_users');
        }

        return $this->render('users/assignusergroup.html.twig',array(
            'form'=>$form->createView()
        ));
    }


    /**
     * @Route("/users/removefromgroup", name="remove_users_group")
     * @Method({"GET", "POST"})
     */
    public function removeUserFromGroup()
    {
        $repository = $this->getDoctrine()->getRepository(TNUserGroups::class);
        $users = $repository->findAll();

        return $this->render(
            'users/removeuserfromgroup.html.twig',
            array('customers' => $users)
        );
    }

    /**
     * @Route("/users/removefromgroup/{id}", name="remove_users_from_group_ID")
     * @Method({"GET", "POST"})
     */
    public function removeUserFromGroupUsingID($id)
    {
        $entityManager = $this->getDoctrine()->getManager();
        $userGroupID = $entityManager->getRepository(TNUserGroups::class)->find($id);

        //print_r($userID);
        //exit();

        if (!$userGroupID)
        {
            throw $this->createNotFoundException("No record for user id:".$id);
        }

        $entityManager->remove($userGroupID);
        $entityManager->flush();

        return $this->redirectToRoute('new_users');
    }

    /**
     * @Route("/users/group", name="new_group")
     * @Method({"GET", "POST"})
     */
    public function newgroup()
    {
        return $this->render(
            'users/grouppage.html.twig');
    }

    /**
     * @Route("/users/group/create", name="group_create")
     * @Method({"GET", "POST"})
     */
    public function createGroup(Request $request)
    {

        $newgroup = new TNGroups();
        $form = $this->createFormBuilder($newgroup)
            ->add('groupName', TextType::class, array('attr' =>array('class' => 'form-control')))
            ->add('groupDescription', TextType::class, array('attr' =>array('class' => 'form-control')))
            ->add('save', SubmitType::class, array(
                'label' =>'Create',
                'attr' =>array('class'=>'btn btn-primary mt-3')
                ))
            ->getForm();

        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid())
        {
            $newdata = $form->getData();
            $entityManager = $this->getDoctrine()->getManager();
            try{

                $entityManager->persist($newdata);
                $entityManager->flush();
            }catch (\Exception $e) {
                return new JsonResponse(["error" => $e->getMessage()], 500);
            }

            return $this->redirectToRoute('new_group');
        }

        return $this->render('users/group.html.twig',array(
                                'form'=>$form->createView()
                            ));

    }

    /**
     * @Route("/users/group/delete", name="group_delete")
     * @Method({"GET", "POST"})
     */
    public function deleteGroup()
    {
        $repository = $this->getDoctrine()->getRepository(TNGroups::class);
        $users = $repository->findAll();

        return $this->render(
            'users/deletegroup.html.twig',
            array('customers' => $users)
        );
    }

    /**
     * @Route("/users/group/delete/{id}", name="delete_groupID")
     * @Method({"GET", "POST"})
     */
    public function deleteGroupID($id)
    {
        $entityManager = $this->getDoctrine()->getManager();
        $groupID = $entityManager->getRepository(TNGroups::class)->find($id);

        if (!$groupID)
        {
            throw $this->createNotFoundException("No record for group id:".$id);
        }

        $entityManager->remove($groupID);
        $entityManager->flush();

        return $this->redirectToRoute('new_group');
    }
    

}
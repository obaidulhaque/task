<?php

namespace App\Repository;

use App\Entity\TNUsers;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Symfony\Bridge\Doctrine\RegistryInterface;

/**
 * @method TNUsers|null find($id, $lockMode = null, $lockVersion = null)
 * @method TNUsers|null findOneBy(array $criteria, array $orderBy = null)
 * @method TNUsers[]    findAll()
 * @method TNUsers[]    findBy(array $criteria, array $orderBy = null, $limit = null, $offset = null)
 */
class TNUsersRepository extends ServiceEntityRepository
{
    public function __construct(RegistryInterface $registry)
    {
        parent::__construct($registry, TNUsers::class);
    }

    // /**
    //  * @return TNUsers[] Returns an array of TNUsers objects
    //  */
    /*
    public function findByExampleField($value)
    {
        return $this->createQueryBuilder('t')
            ->andWhere('t.exampleField = :val')
            ->setParameter('val', $value)
            ->orderBy('t.id', 'ASC')
            ->setMaxResults(10)
            ->getQuery()
            ->getResult()
        ;
    }
    */

    /*
    public function findOneBySomeField($value): ?TNUsers
    {
        return $this->createQueryBuilder('t')
            ->andWhere('t.exampleField = :val')
            ->setParameter('val', $value)
            ->getQuery()
            ->getOneOrNullResult()
        ;
    }
    */
}

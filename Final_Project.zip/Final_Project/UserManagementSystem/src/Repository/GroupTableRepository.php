<?php

namespace App\Repository;

use App\Entity\GroupTable;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Symfony\Bridge\Doctrine\RegistryInterface;

/**
 * @method GroupTable|null find($id, $lockMode = null, $lockVersion = null)
 * @method GroupTable|null findOneBy(array $criteria, array $orderBy = null)
 * @method GroupTable[]    findAll()
 * @method GroupTable[]    findBy(array $criteria, array $orderBy = null, $limit = null, $offset = null)
 */
class GroupTableRepository extends ServiceEntityRepository
{
    public function __construct(RegistryInterface $registry)
    {
        parent::__construct($registry, GroupTable::class);
    }

    // /**
    //  * @return GroupTable[] Returns an array of GroupTable objects
    //  */
    /*
    public function findByExampleField($value)
    {
        return $this->createQueryBuilder('g')
            ->andWhere('g.exampleField = :val')
            ->setParameter('val', $value)
            ->orderBy('g.id', 'ASC')
            ->setMaxResults(10)
            ->getQuery()
            ->getResult()
        ;
    }
    */

    /*
    public function findOneBySomeField($value): ?GroupTable
    {
        return $this->createQueryBuilder('g')
            ->andWhere('g.exampleField = :val')
            ->setParameter('val', $value)
            ->getQuery()
            ->getOneOrNullResult()
        ;
    }
    */
}

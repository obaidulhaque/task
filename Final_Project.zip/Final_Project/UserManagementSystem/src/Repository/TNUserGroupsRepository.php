<?php

namespace App\Repository;

use App\Entity\TNUserGroups;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Symfony\Bridge\Doctrine\RegistryInterface;

/**
 * @method TNUserGroups|null find($id, $lockMode = null, $lockVersion = null)
 * @method TNUserGroups|null findOneBy(array $criteria, array $orderBy = null)
 * @method TNUserGroups[]    findAll()
 * @method TNUserGroups[]    findBy(array $criteria, array $orderBy = null, $limit = null, $offset = null)
 */
class TNUserGroupsRepository extends ServiceEntityRepository
{
    public function __construct(RegistryInterface $registry)
    {
        parent::__construct($registry, TNUserGroups::class);
    }

    // /**
    //  * @return TNUserGroups[] Returns an array of TNUserGroups objects
    //  */
    /*
    public function findByExampleField($value)
    {
        return $this->createQueryBuilder('t')
            ->andWhere('t.exampleField = :val')
            ->setParameter('val', $value)
            ->orderBy('t.id', 'ASC')
            ->setMaxResults(10)
            ->getQuery()
            ->getResult()
        ;
    }
    */

    /*
    public function findOneBySomeField($value): ?TNUserGroups
    {
        return $this->createQueryBuilder('t')
            ->andWhere('t.exampleField = :val')
            ->setParameter('val', $value)
            ->getQuery()
            ->getOneOrNullResult()
        ;
    }
    */
}

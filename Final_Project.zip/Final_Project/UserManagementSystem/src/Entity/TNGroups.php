<?php

namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;


/**
 * @ORM\Entity(repositoryClass="App\Repository\TNGroupsRepository")
 */
class TNGroups
{
    /**
     * @ORM\Id()
     * @ORM\GeneratedValue()
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=30, unique=true)
     */
    private $groupName;

    /**
     * @ORM\Column(type="string", length=255, nullable=true)
     */
    private $groupDescription;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getGroupName(): ?string
    {
        return $this->groupName;
    }

    public function setGroupName(string $groupName): self
    {
        $this->groupName = $groupName;

        return $this;
    }

    public function getGroupDescription(): ?string
    {
        return $this->groupDescription;
    }

    public function setGroupDescription(?string $groupDescription): self
    {
        $this->groupDescription = $groupDescription;

        return $this;
    }

    public function __toString(){

        return $this->groupName;
    }
}
